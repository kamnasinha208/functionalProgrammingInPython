llist = [1, 2, 3]
addlist = list(map(lambda x: x + 2, llist))
print(addlist)