

print((lambda gp: 'good' if gp > 8 else 'sufficient' if gp > 5 else 'insufficient')(4))