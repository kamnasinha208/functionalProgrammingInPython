''''functional implementation of simple calculator'''
def f_main():

    return f_calculate( f_getNum() , f_getOp() , f_getNum())

def f_calculate(num1 , op , num2):
    return num1+num2 if op == '+' else num1-num2 if op == '-' else num1*num2 if op == '*' else num1/num2 if op == '/' else None

def f_getNum():
    return int(input("enter integer: "))

def f_getOp():
    return  input("enter op: ")

print ("The result is : %s" % f_main())