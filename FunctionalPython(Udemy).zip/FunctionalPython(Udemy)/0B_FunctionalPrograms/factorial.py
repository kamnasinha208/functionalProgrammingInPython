l_factorial = lambda n: 1 if n==0 else n*l_factorial(n-1)

print(l_factorial(4))