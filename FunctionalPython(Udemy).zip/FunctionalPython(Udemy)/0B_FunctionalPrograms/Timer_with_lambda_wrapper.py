
import time

l_factorial = lambda n : 1 if n == 0 else n*l_factorial(n-1)

l_timestamp = lambda fnc, arg : (time.time() , fnc(arg), time.time())

l_diff = lambda t0, result , t1 : (t1-t0)

l_timer = lambda fnc , arg : l_diff(*l_timestamp(fnc , arg))

print("it took %.5f seconds" % l_timer(l_factorial, 900))