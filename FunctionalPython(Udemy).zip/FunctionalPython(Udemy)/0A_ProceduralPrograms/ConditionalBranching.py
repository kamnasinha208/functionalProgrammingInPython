def gp_description(gp):

    if gp > 8 :
        return 'good'
    if gp > 5 :
        return 'sufficient'
    return 'insufficient'

print(gp_description(7))