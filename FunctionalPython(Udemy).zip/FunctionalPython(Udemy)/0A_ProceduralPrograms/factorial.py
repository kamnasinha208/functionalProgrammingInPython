def f_fact(n):
    return 1 if n == 0 else n*f_fact(n-1)

print(f_fact(3))