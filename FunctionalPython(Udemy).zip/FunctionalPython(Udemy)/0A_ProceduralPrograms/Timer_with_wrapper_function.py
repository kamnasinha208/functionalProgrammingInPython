
import time
l_factorial = lambda n : 1 if n == 0 else n*l_factorial(n-1)
def timer(fnc , arg):

    t0 = time.time()
    fnc(arg)
    t1 = time.time()

    return t1-t0

print("it took %.5f seconds" % timer(l_factorial,900))