

l_factorial = lambda n : 1 if n == 0 else n*l_factorial(n-1)
print(l_factorial(3))
import time

t0 = time.time()
print(t0)
print(l_factorial(900))
t1 = time.time()
print(t1)

print("it took %.5f seconds" % (t1-t0))