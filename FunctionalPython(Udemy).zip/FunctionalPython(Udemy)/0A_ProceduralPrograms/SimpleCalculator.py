OPERATORS = '+', '-','*','/'

def p_main():
    print("Welcome to functional calculator")
    num1 = p_get_num()
    num2 = p_get_num()
    operator = p_get_operator()
    result = p_calculator(num1 , operator , num2)

    print('the result is : %s' % result)

def p_get_num():

    while True:
        s = input("enter an integer : ")
        try :
            return int(s)
        except ValueError:
            print("not an integer")

def p_get_operator():

    while True:
        s = input("enter an operator: ")
        if s in OPERATORS:
            return s
        print("not an operator")

def p_calculator(num1 ,operator , num2 ):

    if operator == '+':
        return num1 + num2
    if operator == '-':
        return num1 - num2
    if operator == '*':
        return num1*num2
    if operator == '/':
        return num1/num2
    raise Exception('invalid operator')

p_main()