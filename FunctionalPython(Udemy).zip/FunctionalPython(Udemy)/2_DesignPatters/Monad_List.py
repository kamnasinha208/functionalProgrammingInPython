"""
Variables that decide how they should be treated.

List monad defines a series of values , 'a given function is applied to each value in the list

result is a new list monad

"""
def camelcase(s):
    return ''.join([w.capitalize() for w in s.split('_')])

class List:
    def __init__(self, values):
        self.values = values

    def bind(self, fnc):
        return List([fnc(val) for val in self.values])
    def __repr__(self):
        return str(self.values)

print(List(['some_text', 'some_more']).bind(camelcase))