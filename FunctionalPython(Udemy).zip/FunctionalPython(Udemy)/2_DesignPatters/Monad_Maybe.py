"""
Variables that decide how they should be treated.
2 kinds of values in maybe monad:
    normal - JUST
    invalid - NOTHING

any function applied to nothing returns nothing

"""

def camelcase(s):
    return ''.join([w.capitalize() for w in s.split('_')])

print(camelcase('some_func'))

class Just:
    def __init__(self, value):
        self._value = value

    def bind(self, fnc):
        try:
            return Just(fnc(self._value))
        except:
            return Nothing()
    def __repr__(self):
        return self._value

class Nothing:
    def bind(self, fnc):
        return Nothing()
    def __repr__(self):
        return 'Nothing'


print(Just('some_func').bind(camelcase))
print(Nothing().bind(camelcase))

#for invalid value passed to Just :

print(Just(10).bind(camelcase))