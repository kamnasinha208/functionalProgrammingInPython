"""
converting a function that takes more than one args to a chain of higher order functions which tke one arg
(using Decorator)
"""

from inspect import signature
from functools import partial

def curry(fnc):
    def inner(arg):
        if len(signature(fnc).parameters) == 1:
            return fnc(arg)
        return curry(partial(fnc,arg))
    return inner

@curry
def add(a,b,c):
    return a + b + c

print(add(10)(100)(1000))

