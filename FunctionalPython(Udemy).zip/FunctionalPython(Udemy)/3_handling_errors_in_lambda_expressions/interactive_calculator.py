OPERATORS= '+','-','*','/'
"""
maybe function : turns exceptions into return values
"""
def maybe(fnc):
    def inner(*args):  #this function is like a maybe function - handles nothing and just values

        for a in args:  # for determining if arguments itself had an instance of Exception then this becomes "Nothing" value
            if isinstance(a,Exception):      # and is returned as is
                return a
        try:
            return fnc(*args)  # if " Just" value gives a valid result
        except Exception as e: # if "just" value gives invalid result , its treated as "Nothing" value and
            return e                # is returned as exxception

    return inner

"""
repeat functions : repeats function until its return value meets the stop criterian
"""

def repeat(fnc, until):
    def inner(*args):
        while True:
            result = fnc(*args)
            if until(result):
                return result
    return inner

getNum = lambda : int(input("enter integer: "))

is_int = lambda i: isinstance(i, int)
safe_getNum = repeat( maybe(getNum), until=is_int)

getOp = lambda: input("enter op: ")

is_op = lambda o: o in OPERATORS
safe_getOp = repeat(getOp, until=is_op)

calculate = lambda num1 , op , num2 : \
    num1+num2 if op == '+' \
    else num1-num2 if op == '-' \
    else num1*num2 if op == '*' \
    else num1/num2 if op == '/' \
    else None
main = lambda : calculate(safe_getNum(), safe_getOp(), safe_getNum())

forever = lambda retval: False
main_loop = repeat(lambda : print(main()), until=forever)
print ("The result is : %s" % main_loop())
