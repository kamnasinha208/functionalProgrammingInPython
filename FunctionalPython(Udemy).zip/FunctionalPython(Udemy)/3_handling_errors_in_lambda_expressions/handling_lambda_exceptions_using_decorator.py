"""
wrap the lambda expression call inside another function like decorator so that exceptions can be caught
kind of maybe design pattern
"""

def maybe(fnc):
    def inner(*args):  #this function is like a maybe function - handles nothing and just values

        for a in args:  # for determining if arguments itself had an instance of Exception then this becomes "Nothing" value
            if isinstance(a,Exception):      # and is returned as is
                return a
        try:
            return fnc(*args)  # if " Just" value gives a valid result
        except Exception as e: # if "just" value gives invalid result , its treated as "Nothing" value and
            return e                # is returned as exxception

    return inner

safe_add_str = maybe(lambda s: sum([int(i) for i in s.split('+')]))

print(safe_add_str('1+2+3'))