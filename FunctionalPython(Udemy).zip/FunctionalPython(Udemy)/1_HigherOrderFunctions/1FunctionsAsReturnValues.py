
pre_heat = lambda : print("pre-heating oven")
put_bread = lambda : print("putting doe in oven")
wait_5min = lambda : print("wait for bread to cook")
eat = lambda : print("enjoy the bread")


def create_recpe(*functions):

    def run_all():
        for function in functions:
            function()

    return run_all()


recipe = create_recpe(pre_heat , put_bread, wait_5min, eat)