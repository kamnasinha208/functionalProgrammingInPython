#For Factorial .............


l_factorial = lambda n: 1 if n==0 else n*l_factorial(n-1)

def chain_mul(*tuple_func_args):
    """

    :param tuple_func_args:
    :return: product of all return values from list of function,arguments pairs passed in as argument.
    """

    total = 1
    for (fnc,arg) in tuple_func_args:
        total *= fnc(arg)
    return total

print(chain_mul((l_factorial,2 ), (l_factorial,3)))